#!/bin/bash
set -x
#compiling the Sum.g4 in java files
java -jar "antlr-4.7.2-complete.jar" -no-listener -visitor gramatica.g4
#exporting the class path
export CLASSPATH=".:antlr-4.7.2-complete.jar:$CLASSPATH"
#compiling the .java generated from Sum.g4 with MyParser.java and AddVisitor.java
javac *.java
for i in 1 2 3 4 5 6 7 8
do
	#feeding a string and reading the tokens
	java org.antlr.v4.gui.TestRig gramatica root -tokens <  "test${i}.sm"
	#feeding a string and reading tree in list style
	java org.antlr.v4.gui.TestRig gramatica root -tree < "test${i}.sm" 
	#execute the implemented visitor
	java MyParser < "test${i}.sm" > "result${i}.txt"
	clear
done
#feeding a string and printing a graphical tree
java org.antlr.v4.gui.TestRig gramatica root -gui < "test7.sm" 
